<?php 

define('SPR', DIRECTORY_SEPARATOR);

define('BASEPATH', dirname(__FILE__));

define('JPATH', BASEPATH . SPR . 'App');

define('JCore', BASEPATH . SPR . 'Core');