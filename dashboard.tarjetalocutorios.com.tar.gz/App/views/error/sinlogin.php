<?php include '../App/views/modules/navbar-top.php'; ?>

<div class="uk-container">
  <div class="uk-grid uk-margin uk-margin-large-bottom uk-margin-large-top">
    <div class="uk-width-1-1">
      <img src="./images/accesodenegado.png" alt="" style="margin: 1rem auto 3rem;display: block;width: 250px;">
      <div class="h1 uk-text-center">ACCESO DENEGADO</div>
    </div>
  </div>
</div>

<?php include '../App/views/modules/footer-main.php'; ?>
