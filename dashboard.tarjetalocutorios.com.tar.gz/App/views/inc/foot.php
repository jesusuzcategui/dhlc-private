		</div>

    <div class="btn-whatsapp" uk-tooltip="SI NECESITAS AYUDA, COMUNICATE CON NOSOTROS">
    <a href="https://api.whatsapp.com/send?phone=56232108264" target="_blank">
    <img src="https://s2.accesoperu.com/logos/btn_whatsapp.png" alt="">
    </a>
    </div>
	<!-- Global site tag (gtag.js) - Google Ads: 10784352771 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-10784352771"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'AW-10784352771');
    </script>

	</body>
	
</html>