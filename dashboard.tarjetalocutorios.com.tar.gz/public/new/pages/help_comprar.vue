<template>
    <div>
        <div class="uk-container">
            <h3 class="uk-text-center uk-heading-primary uk-margin-bottom-large">¿Cómo comprar?</h3>
            <div uk-grid="" class="uk-child-width-1-4@l uk-grid-small uk-grid-divider uk-grid-match">
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-1_01.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-1_02.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-1_03.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-1_04.jpg" alt="Paso" />
                    </div>
                </div>
            </div>

            <div class="uk-margin-top uk-text-center">
                <a href="/#/" class="mdl-typography--text-uppercase mdl-button mdl-js-button mdl-button--raised uk-width-1-1">VAMOS A COMPRAR</a>
            </div>
        </div>
    </div>
</template>
<script>
    module.exports = {
        data(){
            return {};
        },
        methods: {

        }
    };
    
</script>