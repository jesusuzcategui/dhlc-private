<template>
    <div>
        <p>ERROR</p>
    </div>
</template>
<script>

module.exports = {
    data(){
        return {
            token: ''
        }
    },
    mounted() {
    }
};

</script>
