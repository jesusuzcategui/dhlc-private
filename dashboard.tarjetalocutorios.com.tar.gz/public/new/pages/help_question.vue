<template>
    <div>
        <div class="uk-container">
            <h3 class="uk-text-center uk-heading-primary uk-margin-bottom-large">Preguntas frecuentes</h3>

            <ul uk-accordion>
                <li>
                    <a class="uk-accordion-title" href="#">¿Puedo usarlo desde celular y desde telefono fijo?</a>
                    <div class="uk-accordion-content">
                        <p>Sí, funciona desde teléfono fijo o desde celulares</p>
                    </div>
                </li>
                <li>
                    <a class="uk-accordion-title" href="#">¿Tiene costo llamar al numero de acceso?</a>
                    <div class="uk-accordion-content">
                        <p>sí, ocupará saldo de tu telefono la llamada a nuestro numero de acceso</p>
                    </div>
                </li>
                <li>
                    <a class="uk-accordion-title" href="#">¿Solo se puede usar desde Chile?</a>
                    <div class="uk-accordion-content">
                        <p>No, actualmente tenemos numeros de acceso en Chile y en Venezuela.</p>
                    </div>
                </li>
                <li>
                    <a class="uk-accordion-title" href="#">¿Cómo puedo saber el saldo que tengo y los minutos disponibles?</a>
                    <div class="uk-accordion-content">
                        <p>Al momento de hacer uso de tarjeta le indicara el saldo y minutos disponibles.</p>
                    </div>
                </li>
                <li>
                    <a class="uk-accordion-title" href="#">¿Cómo puedo ver el costo por minuto?</a>
                    <div class="uk-accordion-content">
                        <p>En nuestra pagina web tenemos listado de minutos que da tarjeta, según formato a los principales paises</p>
                    </div>
                </li>
                <li>
                    <a class="uk-accordion-title" href="#">¿Cuánto tiempo dura la tarjeta?</a>
                    <div class="uk-accordion-content">
                        <p>Indistintamente del monto la tarjeta tiene duración de 30 dias desde su primer uso</p>
                    </div>
                </li>
            </ul>

            <div class="uk-margin-top uk-text-center">
                <a href="/#/" class="mdl-typography--text-uppercase mdl-button mdl-js-button mdl-button--raised uk-width-1-1">VAMOS A COMPRAR</a>
            </div>
        </div>
    </div>
</template>
<script>
    module.exports = {
        data(){
            return {};
        },
        methods: {

        }
    };
</script>