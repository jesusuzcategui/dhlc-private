<template>
    <div>
        <div class="uk-container">
            <h3 class="uk-text-center uk-heading-primary uk-margin-bottom-large">¿Cómo comprar?</h3>
            <div uk-grid="" class="uk-child-width-1-4@l uk-grid-small uk-grid-divider uk-grid-match">
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-2_01.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-2_02.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-2_03.jpg" alt="Paso" />
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <img src="/public/images/LOCUTORIOS-PAGINA-2_04.jpg" alt="Paso" />
                    </div>
                </div>
            </div>

            <div class="uk-margin">
                <div class="uk-padding-small uk-width-1-1 uk-card uk-card-default">
                    <ul class="uk-subnav uk-subnav-pill" uk-switcher>
                        <li><a class="mdl-typography--text-uppercase mdl-button mdl-js-button mdl-button--raised" href="#">DESDE CHILE</a></li>
                        <li><a class="mdl-typography--text-uppercase mdl-button mdl-js-button mdl-button--raised" href="#">DESDE VENEZUELA</a></li>
                    </ul>
                    <ul class="uk-switcher uk-margin">
                        <li>Llama al 229402111</li>
                        <li>Llama al 02127102186</li>
                    </ul>  
                </div>
                <div class="uk-alert-success" uk-alert="">
                    <h3 class="uk-h1 uk-text-center">00 + Código de país + Número de destino + Tecla #</h3>
                </div>
            </div>

            <div class="uk-margin-top uk-text-center">
                <a href="/#/" class="mdl-typography--text-uppercase mdl-button mdl-js-button mdl-button--raised uk-width-1-1">VAMOS A COMPRAR</a>
            </div>
        </div>
    </div>
</template>
<script>
    module.exports = {
        data(){
            return {};
        },
        methods: {

        }
    };
</script>