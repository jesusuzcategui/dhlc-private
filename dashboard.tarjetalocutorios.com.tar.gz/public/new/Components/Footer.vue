<template>
    <div class="uk-background-secondary uk-padding uk-margin-large-top">
        <footer class="uk-container">
            <div uk-grid>
                <div class="uk-width-2-5">
                    <img src="/public/images/PAGO-SEGURO.png" />
                </div>
                <div class="uk-width-3-5 uk-flex uk-flex-right">
                    <img style="width: 300px" src="/public/images/webpay.png" />
                </div>
            </div>
            <div class="uk-text-center uk-card uk-card-secondary uk-padding-small">
                <p>Locutorios SPA &copy; 2021 - POWERED BY JESUS UZCATEGUI</p>
            </div>
        </footer>
    </div>
</template>
<script>
    module.exports = {
        data(){
            return {};
        },
        methods: {

        },
    };
</script>